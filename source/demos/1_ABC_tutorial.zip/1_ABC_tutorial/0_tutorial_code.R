#------------------------------------------------------------------------
# Welcome to the demo file for R commands
# isobxr package
# https://ttacail.github.io/isobxr/
# Theo Tacail
# 22/03/21
#------------------------------------------------------------------------

# This R document reunites step by step all the commands necessary to run the Getting started demonstrations
# for the main functions used in isobxr: run_isobxr, compose_isobxr, sweep_steady and sweep_dyn.

# Make sure you downloaded the 1_ABC.zip file containing demo xlsx master files:
# https://ttacail.github.io/source/demos/1_ABC_tutorial.zip
# Unzip it and place it in the directory of your choice
# It is strongly advised to avoid using a working directory linked to an online backup server (such as OneDrive),
# since it could cause some issues with adressing of output files.
# If done so, users are then advised to turn the backup server software offline during the use of isobxr functions.

# # if not installed yet, install devtools:
# # comment this command if installed
# install.packages("devtools")

# # if not installed yet; install isobxr from the github source repository
# # comment this command if installed
# devtools::install_github("ttacail/isobxr/isobxr", build_vignettes = TRUE)

# load the isobxr package
library(isobxr)

# set the path to the 1_ABCD folder containing master xlsx files
# this could look like:
workdir_ABC <- "/Users/username/Documents/1_ABC_tutorial"
workdir_ABC <- "/Users/sz18642/OneDrive - University of Bristol/5_isobxr/tutorials/1_ABC_tutorial"

#------------------------------------------------------------------------

#------------------------------------------------------------------------
#------------------- get function documentations ----------------
#------------------------------------------------------------------------

# ?run_isobxr
# ?compose_isobxr
# ?sweep_steady
# ?sweep_dyn

#------------------------------------------------------------------------
#------------------- 4 - Run_isobxr: tutorial ---------------------------
#------------------- (SINGLE RUNS with run_isobxr) ----------------------
#------------------------------------------------------------------------

# This section shows how to use run_isobxr for single box model runs
# This section corresponds to the commands for model runs used in the "4 - Run_isobxr: tutorial" vignette
# (https://ttacail.github.io/isobxr/articles/04_Run_isobxr_tutorial.html)

####################################################################################
# 1. Balanced 3-boxes closed system model
# ABC_closed_balanced

# We consider here the case a balanced closed system of 3 finite boxes (flux list *Fx1_ABC_closed_bal*, defined in 0_ISOBXR_MASTER.xlsx).
# For this run we use the *a1* fractionation coefficients list (defined in 0_ISOBXR_MASTER.xlsx file).
# We will run this model for total time of 2500 days with a resolution of 1 calculation every 10 days (250 steps).

run_isobxr(workdir = workdir_ABC, # isobxr master file work. dir.
           SERIES_ID = "ABC_closed_balanced", # series ID of the set of runs
           flux_list_name = "Fx1_ABC_closed_bal", # which flux list from FLUXES sheet
           coeff_list_name = "a1", # which coefficients list from COEFFS sheet
           t_lim = 2500, # how long do I want to run
           nb_steps = 250, # how many steps over this run duration
           time_units = c("d", "yr"), # run time units (days), plot time units (years)
           to_DIGEST_evD_PLOT = TRUE,
           to_DIGEST_CSV_XLS = TRUE,
           to_DIGEST_DIAGRAMS = TRUE) # export plot as pdf

####################################################################################
# 2. Unbalanced 3-boxes closed system model
# ABC_closed_unbalanced

# We consider here the case an unbalanced closed system of 3 finite boxes (flux list *Fx2_ABC_closed_unbal*, defined in 0_ISOBXR_MASTER.xlsx).
# For this run we use the *a1* fractionation coefficients list (defined in 0_ISOBXR_MASTER.xlsx file).
# We will run this model for total time of 2500 days with a resolution of 1 calculation every 10 days (250 steps).

run_isobxr(workdir = workdir_ABC, # isobxr master file work. dir.
           SERIES_ID = "ABC_closed_unbalanced", # series ID of the set of runs
           flux_list_name = "Fx2_ABC_closed_unbal", # which flux list from FLUXES sheet
           coeff_list_name = "a1", # which coefficients list from COEFFS sheet
           t_lim = 2500, # how long do I want to run
           nb_steps = 250, # how many steps over this run duration
           time_units = c("d", "yr"), # run time units (days), plot time units (years)
           to_DIGEST_evD_PLOT = TRUE,
           to_DIGEST_CSV_XLS = TRUE,
           to_DIGEST_DIAGRAMS = TRUE) # export plot as pdf

####################################################################################
# 3. Balanced 3-boxes open system model

# We consider here the case an unbalanced closed system of 3 finite boxes (flux list *Fx3_ABC_open_bal*).  -->
# For this run we use the *a1* fractionation coefficients list.  -->
# We will run this model for total time of 2500 days with a resolution of 1 calculation every 10 days (250 steps).  -->

run_isobxr(workdir = workdir_ABC, # isobxr master file work. dir.
           SERIES_ID = "ABC_open_balanced", # series ID of the set of runs
           flux_list_name = "Fx3_ABC_open_bal", # which flux list from FLUXES sheet
           coeff_list_name = "a1", # which coefficients list from COEFFS sheet
           t_lim = 25000, # how long do I want to run
           nb_steps = 2500, # how many steps over this run duration
           time_units = c("d", "yr"), # run time units (days), plot time units (years)
           to_DIGEST_evD_PLOT = TRUE,
           to_DIGEST_CSV_XLS = TRUE,
           to_DIGEST_DIAGRAMS = TRUE,
           evD_PLOT_time_as_log = FALSE) # export plot as pdf


####################################################################################
# 4.i. Balanced 3-boxes open system model WITH forcing of delta initial values

# We consider here the case an unbalanced closed system of 3 finite boxes (flux list *Fx3_ABC_open_bal*).  -->
# For this run we use the *a1* fractionation coefficients list.  -->
# We will run this model for total time of 2500 days with a resolution of 1 calculation every 10 days (250 steps).  -->

FORCING_DELTA <-
  data.frame(BOXES_ID = c("SOURCE", "C"),
             DELTA_INIT = c(-3, +5))

FORCING_DELTA

run_isobxr(workdir = workdir_ABC, # isobxr master file work. dir.
           SERIES_ID = "ABC_open_balanced_w_forcing_delta", # series ID of the set of runs
           flux_list_name = "Fx3_ABC_open_bal", # which flux list from FLUXES sheet
           coeff_list_name = "a1", # which coefficients list from COEFFS sheet
           t_lim = 25000, # how long do I want to run
           nb_steps = 2500, # how many steps over this run duration
           time_units = c("d", "yr"), # run time units (days), plot time units (years)
           to_DIGEST_evD_PLOT = TRUE,
           to_DIGEST_CSV_XLS = TRUE,
           to_DIGEST_DIAGRAMS = TRUE,
           FORCING_DELTA = FORCING_DELTA)



####################################################################################
# 4.ii. Balanced 3-boxes open system model WITH forcing of size initial values

# We consider here the case an unbalanced closed system of 3 finite boxes (flux list *Fx3_ABC_open_bal*).  -->
# For this run we use the *a1* fractionation coefficients list.  -->
# We will run this model for total time of 2500 days with a resolution of 1 calculation every 10 days (250 steps).  -->

FORCING_SIZE <-
  data.frame(BOXES_ID = c("B", "C"),
             SIZE_INIT = c(50, 1e6))

FORCING_SIZE

run_isobxr(workdir = workdir_ABC, # isobxr master file work. dir.
           SERIES_ID = "ABC_open_balanced_w_forcing_size", # series ID of the set of runs
           flux_list_name = "Fx3_ABC_open_bal", # which flux list from FLUXES sheet
           coeff_list_name = "a1", # which coefficients list from COEFFS sheet
           t_lim = 25000, # how long do I want to run
           nb_steps = 2500, # how many steps over this run duration
           time_units = c("d", "yr"), # run time units (days), plot time units (years)
           to_DIGEST_evD_PLOT = TRUE,
           to_DIGEST_CSV_XLS = TRUE,
           to_DIGEST_DIAGRAMS = TRUE,
           FORCING_SIZE = FORCING_SIZE)


#------------------------------------------------------------------------
#------------------- COMPOSE BOX MODEL SCENARIOS with compose_isobxr ----
#------------------------------------------------------------------------

# This section shows how to use compose_isobxr for box model scenarios
# This section corresponds to the commands for model runs used in the "Getting started 2: composite runs" vignette
# (https://ttacail.github.io/isobxr/articles/Demo_ABCD_composite.html)

####################################################################################
# example #1 - perturbating the fluxes
# see getting started 2 for explanations
# 4_compose_scenario_1_changing_fluxes

workdir <- workdir_ABC # isobxr and compo master file work. dir.
SERIES_ID <- "ABC_change_balance" # series ID of the set of compo runs
time_units <- c("d", "yr") # time units for run (days) and for plots (years)
COMPO_MASTER <- "0_CPS_MASTER_changing_balance.xlsx" # compo master file name
plot_HIDE_BOXES_delta <- c("SINK") # boxes to hide from evD plot
plot_HIDE_BOXES_size <- c("SOURCE", "SINK") # boxes to hide from evS plot

compose_isobxr(workdir,
               SERIES_ID,
               time_units,
               COMPO_MASTER,
               plot_HIDE_BOXES_delta,
               plot_HIDE_BOXES_size,
               EACH_RUN_DIGEST = TRUE,
               to_CPS_DIGEST_CSVs = TRUE)

####################################################################################
# example #2 - changing the source isotope composition
# see getting started 2 for explanations
# ABC_change_source

workdir <- workdir_ABC # isobxr and compo master file work. dir.
SERIES_ID <- "ABC_change_source" # series ID of the set of compo runs
time_units <- c("d", "yr") # time units for run (days) and for plots (years)
COMPO_MASTER <- "0_CPS_MASTER_changing_source.xlsx" # compo master file name
plot_HIDE_BOXES_delta <- c("SINK") # boxes to hide from evD plot
plot_HIDE_BOXES_size <- c("SOURCE", "SINK") # boxes to hide from evS plot

compose_isobxr(workdir,
               SERIES_ID,
               time_units,
               COMPO_MASTER,
               plot_HIDE_BOXES_delta,
               plot_HIDE_BOXES_size,
               EACH_RUN_DIGEST = TRUE,
               to_CPS_DIGEST_CSVs = TRUE)

#------------------------------------------------------------------------
#---- sweep the space of parameters at final state with sweep_steady ----
#------------------------------------------------------------------------

# This section shows how to use sweep_steady
# This section corresponds to the commands for model run used in the "Using isboxr" vignette
# in the "Using sweep_steady" section;
# (https://ttacail.github.io/isobxr/articles/isobxr_vignette.html#using-sweep-steady)

# sweep steady
workdir <- workdir_ABC # isobxr and compo master file work. dir.
SERIES_ID <- "ABC_sweep_steady_demo1" # series ID of the set of compo runs
time_units <- c("d", "yr") # time units for run (days) and for plots (years)
EXPLO_MASTER <- "0_SWEEP_STD_MASTER.xlsx" # compo master file name

EXPLO_AXIS_1 <- data.frame(FROM = c("C"),
                           TO = c("B"),
                           ALPHA_MIN = 1,
                           ALPHA_MAX = 1.0005,
                           ALPHA_STEPS = 0.00005,
                           EXPLO_TYPES = "EXPLO_1_ALPHA")

EXPLO_AXIS_2 <- data.frame(FROM = c("A"),
                           TO = c("C"),
                           ALPHA_MIN = 0.9996,
                           ALPHA_MAX = 1,
                           ALPHA_STEPS = 0.00005,
                           EXPLO_TYPES = "EXPLO_1_ALPHA")

sweep_steady(workdir,
             SERIES_ID,
             time_units,
             EXPLO_MASTER,
             EXPLO_AXIS_1,
             EXPLO_AXIS_2,
             to_STD_DIGEST_CSVs = T)

# # sweep std shiny plots
# workdir = workdir_ABC
# runShinyPlots()


#------------------------------------------------------------------------
#---- sweep the space of parameters after perturbation with sweep_dyn ---
#------------------------------------------------------------------------

# This section shows how to use sweep_dyn
# This section corresponds to the commands for model run used in the "Using isboxr" vignette
# in the "Using sweep_dyn" section;
# (https://ttacail.github.io/isobxr/articles/isobxr_vignette.html#using-sweep-dyn)

workdir <- workdir_ABC # isobxr and compo master file work. dir.
SERIES_ID <- "ABC_change_source_sweep_dyn_demo1" # series ID of the set of compo runs
time_units <- c("d", "yr") # time units for run (days) and for plots (years)
EXPLO_MASTER <- "0_SWEEP_DYN_MASTER.xlsx" # compo master file name

EXPLO_AXIS_1 <- data.frame(FROM = c("A"),
                           TO = c("C"),
                           ALPHA_MIN = 0.9988,
                           ALPHA_MAX = 1,
                           ALPHA_STEPS = 0.0004,
                           EXPLO_TYPES = "EXPLO_1_ALPHA")

EXPLO_AXIS_2 <- data.frame(BOXES_ID = c("B"),
                           SIZE_MIN = 500,
                           SIZE_MAX = 4000,
                           SIZE_STEPS = 500,
                           EXPLO_TYPES = "EXPLO_1_SIZE")

sweep_dyn(workdir,
          SERIES_ID,
          time_units,
          EXPLO_MASTER,
          EXPLO_AXIS_1,
          EXPLO_AXIS_2,
          to_DYN_DIGEST_CSVs = T)

# # sweep dyn shiny plots
# workdir = workdir_ABC
# runShinyPlots()

#------------------------------------------------------------------------
#---------------- Plotting with the isobxr plot editor app --------------
#------------------------------------------------------------------------

# This section shows how to use the shiny html locally hosted application for the plotting of isobxr outputs
# This section corresponds to the commands for model run used in the "Using isboxr" vignette
# in the "Plotting with the isobxr plot editor app" section;
# (https://ttacail.github.io/isobxr/articles/isobxr_vignette.html#plotting-with-the-isobxr-plot-editor-app-1)

# declare the workdir value where the output series directories are to be found,
# in this case, it corresponds to the path to the 1_ABCD folder:
workdir = workdir_ABC
# which would be the same as:
# workdir = workdir_ABC

# call the runShinyPlots function and follow the help provided within the app
# the app will open a window in your default web browser
runShinyPlots()


#------------------------------------------------------------------------
#------------------------------------ get portability data --------------
#------------------------------------------------------------------------

# during the beta testing phase, I am collecting some portability data from the beta testers willing to do so.
# This consists in collecting information about
#   * Platform used to run the package (e.g., Windows, Linux, MacOs...)
#   * R versions used
#   * versions of packages used

# You can automatically collect this data by using the get_portability_data function from the isobxr package:
# get_portability_data(workdir = workdir)

# A .Rdata file will be created in the working directory declared to the function
# If you are willing to share this information, I would ask you to send me this .Rdata by mail to
# theo.tacail@gmail.com


#------------------------------------------------------------------------
# ---------------------- Congratulations --------------------------------
#------------------------------------------------------------------------
# You went through the whole basic ABCD demonstration of isobxr.
# You can now explore the functions by yourself.

# Keep in mind that you can always consult the documentation as follows:
# in the vignettes available either online:

# https://ttacail.github.io/isobxr/articles/isobxr_vignette.html
# or locally on your computer:
browseVignettes("isobxr")

# You can also always ask for the documentation for a given function, for instance for run_isobxr:
?run_isobxr









