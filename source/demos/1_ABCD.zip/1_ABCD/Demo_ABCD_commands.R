#------------------------------------------------------------------------
# Welcome to the demo file for R commands
# isobxr package
# https://ttacail.github.io/isobxr/
# Theo Tacail
# 26/10/20
#------------------------------------------------------------------------

# This R document reunites step by step all the commands necessary to run the Getting started demonstrations
# for the main functions used in isobxr: run_isobxr, compose_isobxr, sweep_steady and sweep_dyn.

# Make sure you downloaded the 1_ABCD.zip file containing demo xlsx master files:
# https://ttacail.github.io/source/demos/1_ABCD.zip
# Unzip it and place it in the directory of your choice
# It is strongly advised to avoid using a working directory linked to an online backup server (such as OneDrive),
# since it could cause some issues with adressing of output files.
# If done so, users are then advised to turn the backup server software offline during the use of isobxr functions.

# if not installed yet, install devtools:
# comment this command if installed
install.packages("devtools")

# if not installed yet; install isobxr from the github source repository
# comment this command if installed
devtools::install_github("ttacail/isobxr/isobxr", build_vignettes = TRUE, auth_token = "COPY_PASTE_AUTHOR_TOKEN_SENT_BY_EMAIL")
# (please do not share the author token with others without notifying me during the beta testing phase)

# load the isobxr package
library(isobxr)

# set the path to the 1_ABCD folder containing master xlsx files
# this could look like:
workdir_ABCD <- "/Users/username/Documents/1_ABCD"

#------------------------------------------------------------------------
#------------------- RUNNING SINGLE RUNS with run_isobxr ----------------
#------------------------------------------------------------------------

# This section shows how to use run_isobxr for single box model runs
# This section corresponds to the commands for model runs used in the "Getting started 1: single runs" vignette
# (https://ttacail.github.io/isobxr/articles/Demo_ABCD.html)

####################################################################################
# 1. Balanced 3-boxes closed system model

# We consider here the case a balanced closed system of 3 finite boxes (flux list *Fx1_ABC_bal*, defined in 0_ISOBXR_MASTER.xlsx).
# For this run we use the *a1* fractionation coefficients list (defined in 0_ISOBXR_MASTER.xlsx file).
# We will run this model for total time of 2500 days with a resolution of 1 calculation every 10 days (250 steps).

run_isobxr(workdir = workdir_ABCD, # isobxr master file work. dir.
           SERIES_ID = "ABC_balanced_closed", # series ID of the set of runs
           flux_list_name = "Fx1_ABC_bal", # which flux list from FLUXES sheet
           coeff_list_name = "a1", # which coefficients list from COEFFS sheet
           t_lim = 2500, # how long do I want to run
           nb_steps = 250, # how many steps over this run duration
           time_units = c("days", "years"), # run time units (days), plot time units (years)
           PLOT_evD = TRUE) # export plot as pdf

####################################################################################
# 2. Unbalanced 3-boxes closed system model

# We consider here the case an unbalanced closed system of 3 finite boxes (flux list *Fx2_ABC_unbal*, defined in 0_ISOBXR_MASTER.xlsx).
# For this run we use the *a1* fractionation coefficients list (defined in 0_ISOBXR_MASTER.xlsx file).
# We will run this model for total time of 2500 days with a resolution of 1 calculation every 10 days (250 steps).

run_isobxr(workdir = workdir_ABCD, # isobxr master file work. dir.
           SERIES_ID = "ABC_unbalanced_closed", # series ID of the set of runs
           flux_list_name = "Fx2_ABC_unbal", # which flux list from FLUXES sheet
           coeff_list_name = "a1", # which coefficients list from COEFFS sheet
           t_lim = 2500, # how long do I want to run
           nb_steps = 250, # how many steps over this run duration
           time_units = c("days", "years"), # run time units (days), plot time units (years)
           PLOT_evD = TRUE) # export plot as pdf

####################################################################################
# 3. Balanced 3-boxes open system model

# We consider here the case an unbalanced closed system of 3 finite boxes (flux list *Fx2_ABC_unbal*).  -->
# For this run we use the *a1* fractionation coefficients list.  -->
# We will run this model for total time of 2500 days with a resolution of 1 calculation every 10 days (250 steps).  -->

run_isobxr(workdir = workdir_ABCD, # isobxr master file work. dir.
           SERIES_ID = "ABC_balanced_open", # series ID of the set of runs
           flux_list_name = "Fx6_ABC_open_bal", # which flux list from FLUXES sheet
           coeff_list_name = "a1", # which coefficients list from COEFFS sheet
           t_lim = 25000, # how long do I want to run
           nb_steps = 2500, # how many steps over this run duration
           time_units = c("days", "years"), # run time units (days), plot time units (years)
           PLOT_evD = TRUE) # export plot as pdf

#------------------------------------------------------------------------
#------------------- COMPOSE BOX MODEL SCENARIOS with compose_isobxr ----
#------------------------------------------------------------------------

# This section shows how to use compose_isobxr for box model scenarios
# This section corresponds to the commands for model runs used in the "Getting started 2: composite runs" vignette
# (https://ttacail.github.io/isobxr/articles/Demo_ABCD_composite.html)

####################################################################################
# example #1 - perturbating the fluxes
# see getting started 2 for explanations

workdir <- workdir_ABCD # isobxr and compo master file work. dir.
SERIES_ID <- "ABC_change_balance" # series ID of the set of compo runs
time_units <- c("days", "days") # time units for run (days) and for plots (years)
COMPO_MASTER <- "0_COMPO_MASTER_balance_change.xlsx" # compo master file name
plot_HIDE_BOXES_delta <- c("SINK") # boxes to hide from evD plot
plot_HIDE_BOXES_size <- c("SOURCE", "SINK") # boxes to hide from evS plot

compose_isobxr(workdir,
               SERIES_ID,
               time_units,
               COMPO_MASTER,
               plot_HIDE_BOXES_delta,
               plot_HIDE_BOXES_size)

####################################################################################
# example #2 - changing the source isotope composition
# see getting started 2 for explanations

workdir <- workdir_ABCD # isobxr and compo master file work. dir.
SERIES_ID <- "ABC_change_source" # series ID of the set of compo runs
time_units <- c("days", "days") # time units for run (days) and for plots (years)
COMPO_MASTER <- "0_COMPO_MASTER_source_change.xlsx" # compo master file name
plot_HIDE_BOXES_delta <- c("SINK") # boxes to hide from evD plot
plot_HIDE_BOXES_size <- c("SOURCE", "SINK") # boxes to hide from evS plot

compose_isobxr(workdir,
               SERIES_ID,
               time_units,
               COMPO_MASTER,
               plot_HIDE_BOXES_delta,
               plot_HIDE_BOXES_size)

#------------------------------------------------------------------------
#---- sweep the space of parameters at final state with sweep_steady ----
#------------------------------------------------------------------------

# This section shows how to use sweep_steady
# This section corresponds to the commands for model run used in the "Using isboxr" vignette
# in the "Using sweep_steady" section;
# (https://ttacail.github.io/isobxr/articles/isobxr_vignette.html#using-sweep-steady)

workdir <- workdir_ABCD # isobxr and compo master file work. dir.
SERIES_ID <- "ABC_sweep_steady_demo1" # series ID of the set of compo runs
time_units <- c("days", "days") # time units for run (days) and for plots (years)
EXPLO_MASTER <- "0_SWEEP_STEADY_MASTER_demo1.xlsx" # compo master file name

EXPLO_AXIS_1 <- data.frame(FROM = c("C"),
                           TO = c("B"),
                           ALPHA_MIN = 1,
                           ALPHA_MAX = 1.0005,
                           ALPHA_STEPS = 0.00005,
                           EXPLO_TYPES = "EXPLO_1_ALPHA")

EXPLO_AXIS_2 <- data.frame(FROM = c("A"),
                           TO = c("C"),
                           ALPHA_MIN = 0.9996,
                           ALPHA_MAX = 1,
                           ALPHA_STEPS = 0.00005,
                           EXPLO_TYPES = "EXPLO_1_ALPHA")

sweep_steady(workdir,
             SERIES_ID,
             time_units,
             EXPLO_MASTER,
             EXPLO_AXIS_1,
             EXPLO_AXIS_2)


#------------------------------------------------------------------------
#---- sweep the space of parameters after perturbation with sweep_dyn ---
#------------------------------------------------------------------------

# This section shows how to use sweep_dyn
# This section corresponds to the commands for model run used in the "Using isboxr" vignette
# in the "Using sweep_dyn" section;
# (https://ttacail.github.io/isobxr/articles/isobxr_vignette.html#using-sweep-dyn)


workdir <- workdir_ABCD # isobxr and compo master file work. dir.
SERIES_ID <- "ABC_change_source_sweep_dyn_demo1" # series ID of the set of compo runs
time_units <- c("days", "days") # time units for run (days) and for plots (years)
EXPLO_MASTER <- "0_SWEEP_DYN_MASTER_demo1.xlsx" # compo master file name

EXPLO_AXIS_1 <- data.frame(BOXES_ID = c("B"),
                           SIZE_MIN = 1500,
                           SIZE_MAX = 2500,
                           SIZE_STEPS = 250,
                           EXPLO_TYPES = "EXPLO_1_SIZE")

EXPLO_AXIS_2 <- data.frame(FROM = c("A"),
                           TO = c("C"),
                           ALPHA_MIN = 0.9988,
                           ALPHA_MAX = 1,
                           ALPHA_STEPS = 0.0004,
                           EXPLO_TYPES = "EXPLO_1_ALPHA")

sweep_dyn(workdir,
          SERIES_ID,
          time_units,
          EXPLO_MASTER,
          EXPLO_AXIS_1,
          EXPLO_AXIS_2)

#------------------------------------------------------------------------
#---------------- Plotting with the isobxr plot editor app --------------
#------------------------------------------------------------------------

# This section shows how to use the shiny html locally hosted application for the plotting of isobxr outputs
# This section corresponds to the commands for model run used in the "Using isboxr" vignette
# in the "Plotting with the isobxr plot editor app" section;
# (https://ttacail.github.io/isobxr/articles/isobxr_vignette.html#plotting-with-the-isobxr-plot-editor-app-1)

# declare the workdir value where the output series directories are to be found,
# in this case, it corresponds to the path to the 1_ABCD folder:
workdir = "/Users/username/Documents/1_ABCD"
# which would be the same as:
# workdir = workdir_ABCD

# call the runShinyPlots function and follow the help provided within the app
# the app will open a window in your default web browser
runShinyPlots()


#------------------------------------------------------------------------
#------------------------------------ get portability data --------------
#------------------------------------------------------------------------

# during the beta testing phase, I am collecting some portability data from the beta testers willing to do so.
# This consists in collecting information about
#   * Platform used to run the package (e.g., Windows, Linux, MacOs...)
#   * R versions used
#   * versions of packages used

# You can automatically collect this data by using the get_portability_data function from the isobxr package:
get_portability_data(workdir = workdir)

# A .Rdata file will be created in the working directory declared to the function
# If you are willing to share this information, I would ask you to send me this .Rdata by mail to
# theo.tacail@gmail.com


#------------------------------------------------------------------------
# ---------------------- Congratulations --------------------------------
#------------------------------------------------------------------------
# You went through the whole basic ABCD demonstration of isobxr.
# You can now explore the functions by yourself.

# Keep in mind that you can always consult the documentation as follows:
# in the vignettes available either online:

# https://ttacail.github.io/isobxr/articles/isobxr_vignette.html
# or locally on your computer:
browseVignettes("isobxr")

# You can also always ask for the documentation for a given function, for instance for run_isobxr:
?run_isobxr









